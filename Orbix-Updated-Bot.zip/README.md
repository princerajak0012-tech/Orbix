# Orbix Updated Discord Bot

## Commands
- `/link`: DM/server; private one-time confirmation.
- `/ask`: DM/server; server reply ephemeral, DM reply remains in DM history.
- `@Orbix question`: AI reply in DMs and servers.
- `/help`, `/profile`, `/badges`, `/spoofgame`, `/about`: DM-only.
- All commands and AI mentions require membership in https://discord.gg/Mb6EwCcuk5.

`/spoofgame games hours` is a local planning calculator only. It does not send simulated activity to Discord or unlock badges.

## Setup
1. Python 3.10+ recommended.
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env` and fill credentials.
4. Enable **Server Members Intent** and **Message Content Intent** in Developer Portal.
5. Make sure the bot is in the required server and `REQUIRED_GUILD_ID` is correct.
6. Run `python bot.py`.

## Gemini API
Set `AI_API_KEY`, `AI_MODEL=gemini-2.5-flash`, and
`AI_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai`.
AI errors (including HTTP status and response details) are logged in Termux.

## Message visibility
`/link` confirmation is ephemeral. Other DM command responses remain in DM history. `/ask` responses in servers are ephemeral. Mention replies are normal messages.

Never collect Discord user tokens, passwords, or cookies. Keep `.env` private; `.gitignore` excludes it.
