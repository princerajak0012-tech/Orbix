import os, sqlite3, logging
from datetime import datetime, timezone
import aiohttp, discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("DISCORD_BOT_TOKEN", "").strip()
GUILD_ID = int(os.getenv("REQUIRED_GUILD_ID", "0") or 0)
API_KEY = os.getenv("AI_API_KEY", os.getenv("OPENAI_API_KEY", "")).strip()
MODEL = os.getenv("AI_MODEL", os.getenv("OPENAI_MODEL", "gemini-2.5-flash")).strip()
BASE_URL = os.getenv("AI_BASE_URL", os.getenv("OPENAI_BASE_URL", "https://generativelanguage.googleapis.com/v1beta/openai")).rstrip("/")
INVITE = os.getenv("SUPPORT_SERVER_INVITE", "https://discord.gg/Mb6EwCcuk5")
DB_PATH = os.getenv("DATABASE_PATH", "orbix.sqlite3")
if not TOKEN: raise RuntimeError("DISCORD_BOT_TOKEN missing from .env")
if not GUILD_ID: raise RuntimeError("REQUIRED_GUILD_ID missing from .env")

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
log = logging.getLogger("orbix")
intents = discord.Intents.default()
intents.members = True
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.execute("CREATE TABLE IF NOT EXISTS linked_accounts (discord_user_id TEXT PRIMARY KEY, linked_at TEXT NOT NULL)")
        db.commit()

def linked(uid):
    with sqlite3.connect(DB_PATH) as db:
        return db.execute("SELECT 1 FROM linked_accounts WHERE discord_user_id=?", (str(uid),)).fetchone() is not None

def save_link(uid):
    with sqlite3.connect(DB_PATH) as db:
        db.execute("INSERT OR REPLACE INTO linked_accounts VALUES (?,?)", (str(uid), datetime.now(timezone.utc).isoformat()))
        db.commit()

async def is_member(uid):
    guild = bot.get_guild(GUILD_ID)
    if guild is None:
        try: guild = await bot.fetch_guild(GUILD_ID)
        except discord.HTTPException:
            log.exception("Cannot access required server; check its ID and bot membership.")
            return False
    try:
        await guild.fetch_member(uid)
        return True
    except discord.NotFound: return False
    except discord.HTTPException:
        log.exception("Membership verification failed.")
        return False

async def gate(inter):
    if await is_member(inter.user.id): return True
    msg = f"Join the Orbix support server before using commands: {INVITE}"
    if inter.response.is_done(): await inter.followup.send(msg, ephemeral=True)
    else: await inter.response.send_message(msg, ephemeral=True)
    return False

async def ask_ai(prompt, user):
    if not API_KEY: return "AI is not configured. Add AI_API_KEY to .env."
    payload = {"model": MODEL, "messages": [
        {"role":"system","content":"You are Orbix, a concise Discord bot helper. Explain commands and legitimate public badge information. Commands: /link, /help, /profile, /badges, /spoofgame, /ask, /about. /spoofgame only calculates a local game-time plan; it does not submit fake Discord activity or unlock badges. Never request Discord account tokens, passwords, cookies, or authentication codes. Users must join the support server."},
        {"role":"user","content":f"{user}: {prompt[:1800]}"}
    ], "temperature":0.5, "max_tokens":500}
    try:
        timeout = aiohttp.ClientTimeout(total=35)
        async with aiohttp.ClientSession(timeout=timeout) as s:
            async with s.post(BASE_URL+"/chat/completions",
                headers={"Authorization":"Bearer "+API_KEY,"Content-Type":"application/json"}, json=payload) as r:
                body = await r.text()
                if r.status >= 400:
                    log.error("AI API HTTP %s: %s", r.status, body[:1200])
                    if r.status in (401,403): return "Gemini rejected the API key. Check AI_API_KEY."
                    if r.status == 429: return "Gemini rate limit or quota reached. Try later."
                    return f"AI provider error (HTTP {r.status}). Check the Termux log."
                data = await r.json()
                return data["choices"][0]["message"]["content"].strip()[:1900]
    except aiohttp.ClientError:
        log.exception("AI network error")
        return "Cannot connect to Gemini. Check internet and try again."
    except (KeyError, IndexError, TypeError, ValueError):
        log.exception("Unexpected AI response")
        return "Gemini returned an unexpected response. Check model and API endpoint."

@bot.event
async def on_ready():
    try:
        cmds = await bot.tree.sync()
        log.info("ONLINE as %s (%s); synced %d commands", bot.user, bot.user.id, len(cmds))
    except Exception: log.exception("Command sync failed")

@bot.tree.command(name="link", description="Link your Discord identity to Orbix")
@app_commands.allowed_contexts(guilds=True, dms=True, private_channels=False)
@app_commands.allowed_installs(guilds=True, users=True)
async def link(inter):
    if not await gate(inter): return
    save_link(inter.user.id)
    await inter.response.send_message("✅ Your Discord identity is linked. No account token or password was requested.", ephemeral=True)

@bot.tree.command(name="help", description="Show Orbix commands")
@app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
@app_commands.allowed_installs(guilds=True, users=True)
async def help_cmd(inter):
    if not await gate(inter): return
    await inter.response.defer(ephemeral=False, thinking=True)
    e=discord.Embed(title="Orbix — Help", description="Most commands are DM-only. /link and /ask work in DMs and servers.", color=discord.Color.blurple())
    e.add_field(name="/link", value="Link your Discord identity; private one-time confirmation.", inline=False)
    e.add_field(name="/profile", value="View profile basics.", inline=False)
    e.add_field(name="/badges", value="View public badge flags exposed by Discord.", inline=False)
    e.add_field(name="/spoofgame games hours", value="Local planning calculator only; does not alter Discord activity or badges.", inline=False)
    e.add_field(name="/ask question", value="Ask Orbix AI.", inline=False)
    e.add_field(name="@Orbix question", value="Mention Orbix in a DM or server for AI help.", inline=False)
    e.add_field(name="/about", value="Bot information.", inline=False)
    await inter.followup.send(embed=e)

@bot.tree.command(name="profile", description="View your Discord profile")
@app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
@app_commands.allowed_installs(guilds=True, users=True)
async def profile(inter):
    if not await gate(inter): return
    await inter.response.defer(ephemeral=False, thinking=True)
    u=inter.user
    e=discord.Embed(title=f"{u.display_name}'s profile", color=discord.Color.blurple())
    e.add_field(name="Username",value=str(u),inline=True)
    e.add_field(name="User ID",value=str(u.id),inline=True)
    e.add_field(name="Account created",value=discord.utils.format_dt(u.created_at,style="D"),inline=False)
    e.add_field(name="Linked to Orbix",value="Yes" if linked(u.id) else "No — use /link",inline=False)
    e.set_thumbnail(url=u.display_avatar.url)
    await inter.followup.send(embed=e)

@bot.tree.command(name="badges", description="View public Discord profile badges")
@app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
@app_commands.allowed_installs(guilds=True, users=True)
async def badges(inter):
    if not await gate(inter): return
    await inter.response.defer(ephemeral=False, thinking=True)
    flags=getattr(inter.user,"public_flags",None)
    names=[]
    if flags:
        try: names=[x.name.replace("_"," ").title() for x in flags]
        except Exception: log.exception("Badge flag parsing failed")
    e=discord.Embed(title="Public profile badges",description="\\n".join("• "+n for n in names) if names else "No public badge flags were returned. Not every profile decoration is exposed by Discord's bot API.",color=discord.Color.blurple())
    e.set_footer(text="Read-only; Orbix cannot grant or modify badges.")
    await inter.followup.send(embed=e)

@bot.tree.command(name="spoofgame", description="Calculate a local game-time plan (no Discord activity changes)")
@app_commands.describe(games="Number of game entries", hours="Planned hours per game")
@app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
@app_commands.allowed_installs(guilds=True, users=True)
async def spoofgame(inter, games: app_commands.Range[int,1,20], hours: app_commands.Range[float,0.5,24.0]):
    if not await gate(inter): return
    await inter.response.defer(ephemeral=False, thinking=True)
    e=discord.Embed(title="Game-time plan — local demo",description=f"**Game entries:** {games}\\n**Hours per game:** {hours:g}\\n**Total planned time:** {games*hours:g} hours\\n\\nThis is only a calculator. It does not simulate Discord activity or unlock badges.",color=discord.Color.blurple())
    await inter.followup.send(embed=e)

@bot.tree.command(name="ask", description="Ask Orbix AI")
@app_commands.describe(question="Your question")
@app_commands.allowed_contexts(guilds=True,dms=True,private_channels=False)
@app_commands.allowed_installs(guilds=True,users=True)
async def ask(inter, question: str):
    if not await gate(inter): return
    private = inter.guild is not None
    await inter.response.defer(ephemeral=private,thinking=True)
    await inter.followup.send(await ask_ai(question,str(inter.user)),ephemeral=private)

@bot.tree.command(name="about", description="About Orbix")
@app_commands.allowed_contexts(guilds=False,dms=True,private_channels=False)
@app_commands.allowed_installs(guilds=True,users=True)
async def about(inter):
    if not await gate(inter): return
    await inter.response.send_message("Orbix provides read-only public badge/profile information, AI help, and a local game-time calculator. It never collects account tokens or manipulates badge progress.")

@bot.event
async def on_message(msg):
    if msg.author.bot: return
    if bot.user and bot.user in msg.mentions:
        if not await is_member(msg.author.id):
            await msg.reply(f"Join the support server first: {INVITE}",mention_author=False)
            return
        prompt=msg.content.replace(f"<@{bot.user.id}>","").replace(f"<@!{bot.user.id}>","").strip()
        if not prompt: await msg.reply("Mention me with a question or use /ask.",mention_author=False)
        else:
            async with msg.channel.typing():
                await msg.reply(await ask_ai(prompt,str(msg.author)),mention_author=False)
    await bot.process_commands(msg)

init_db()
bot.run(TOKEN)
