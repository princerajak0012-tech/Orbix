import os
import sqlite3
import logging
from datetime import datetime, timezone

import aiohttp
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_BOT_TOKEN", "").strip()
REQUIRED_GUILD_ID = int(os.getenv("REQUIRED_GUILD_ID", "0") or 0)
AI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
AI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini").strip()
AI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
SUPPORT_SERVER_INVITE = os.getenv(
    "SUPPORT_SERVER_INVITE", "https://discord.gg/Mb6EwCcuk5"
).strip()

if not TOKEN:
    raise RuntimeError("DISCORD_BOT_TOKEN is missing. Copy .env.example to .env and fill it in.")
if not REQUIRED_GUILD_ID:
    raise RuntimeError("REQUIRED_GUILD_ID is missing. Set it to your support server ID.")

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("badge-bot")

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)
DB_PATH = os.getenv("DATABASE_PATH", "bot.sqlite3")

def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS linked_accounts (
                discord_user_id TEXT PRIMARY KEY,
                linked_at TEXT NOT NULL
            )
        """)
        db.commit()

def is_linked(user_id: int) -> bool:
    with sqlite3.connect(DB_PATH) as db:
        row = db.execute(
            "SELECT 1 FROM linked_accounts WHERE discord_user_id = ?",
            (str(user_id),)
        ).fetchone()
    return row is not None

def save_link(user_id: int):
    with sqlite3.connect(DB_PATH) as db:
        db.execute(
            "INSERT OR REPLACE INTO linked_accounts(discord_user_id, linked_at) VALUES (?, ?)",
            (str(user_id), datetime.now(timezone.utc).isoformat())
        )
        db.commit()

async def is_member_of_required_server(user_id: int) -> bool:
    guild = bot.get_guild(REQUIRED_GUILD_ID)
    if guild is None:
        try:
            guild = await bot.fetch_guild(REQUIRED_GUILD_ID)
        except discord.HTTPException:
            log.exception("Cannot access required server. Check REQUIRED_GUILD_ID and bot membership.")
            return False
    try:
        await guild.fetch_member(user_id)
        return True
    except discord.NotFound:
        return False
    except discord.HTTPException:
        log.exception("Could not verify server membership.")
        return False

async def gate(interaction: discord.Interaction) -> bool:
    if await is_member_of_required_server(interaction.user.id):
        return True
    msg = (
        "You need to join the support server before using this bot's commands.\n"
        f"Join here: {SUPPORT_SERVER_INVITE}\n"
        "After joining, run the command again."
    )
    if interaction.response.is_done():
        await interaction.followup.send(msg, ephemeral=True)
    else:
        await interaction.response.send_message(msg, ephemeral=True)
    return False

async def ai_reply(prompt: str, user_label: str = "Discord user") -> str:
    if not AI_API_KEY:
        return "AI is not configured yet. The bot owner needs to add OPENAI_API_KEY to the .env file."
    url = f"{AI_BASE_URL}/chat/completions"
    headers = {"Authorization": f"Bearer {AI_API_KEY}", "Content-Type": "application/json"}
    system = (
        "You are Badge Buddy, a concise and friendly assistant for this Discord bot. "
        "Explain commands and legitimate Discord profile badge information. "
        "Never claim you can grant badges, fake activity, alter Discord analytics, or unlock badges. "
        "Never ask for passwords, user tokens, cookies, or authentication codes. "
        "If asked how to use the bot, explain /link, /help, /profile, and /badges. "
        "Commands are primarily used in DMs; /link and /ask are available in DMs and servers. "
        "The user must join the configured support server before using commands."
    )
    payload = {
        "model": AI_MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": f"{user_label}: {prompt[:1500]}"}
        ],
        "temperature": 0.5,
        "max_tokens": 450
    }
    timeout = aiohttp.ClientTimeout(total=25)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.post(url, headers=headers, json=payload) as resp:
            if resp.status >= 400:
                body = await resp.text()
                log.error("AI API error %s: %s", resp.status, body[:500])
                return "I couldn't reach the AI service right now. Please try again later."
            data = await resp.json()
            return data["choices"][0]["message"]["content"].strip()[:1900]

@bot.event
async def on_ready():
    try:
        synced = await bot.tree.sync()
        log.info("Synced %d application commands.", len(synced))
    except Exception:
        log.exception("Command sync failed")
    log.info("Logged in as %s (%s)", bot.user, bot.user.id if bot.user else "unknown")

# /link is an app-side registration. It does NOT ask for or store a Discord user token.
@bot.tree.command(name="link", description="Link your Discord identity to this bot")
@app_commands.allowed_contexts(guilds=True, dms=True, private_channels=False)
@app_commands.allowed_installs(guilds=True, users=True)
async def link(interaction: discord.Interaction):
    if not await gate(interaction):
        return
    save_link(interaction.user.id)
    await interaction.response.send_message(
        "✅ Your Discord identity is linked to this bot. No account token or password was collected.",
        ephemeral=True
    )

@bot.tree.command(name="help", description="Show bot commands and instructions")
@app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
@app_commands.allowed_installs(guilds=True, users=True)
async def help_command(interaction: discord.Interaction):
    if not await gate(interaction):
        return
    embed = discord.Embed(
        title="Badge Buddy — Help",
        description="Commands are primarily used in DMs. `/link` and `/ask` also work in servers.",
        color=discord.Color.blurple()
    )
    embed.add_field(name="/link", value="Link your Discord identity to this bot.", inline=False)
    embed.add_field(name="/profile", value="Show your Discord profile basics.", inline=False)
    embed.add_field(name="/badges", value="Show badges Discord makes publicly visible on your profile.", inline=False)
    embed.add_field(name="/ask question", value="Ask the AI assistant about the bot or legitimate badge information.", inline=False)
    embed.add_field(name="AI in servers", value="Mention the bot to ask a question.", inline=False)
    embed.set_footer(text="This bot cannot grant badges or alter Discord badge progress.")
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="profile", description="View your Discord profile basics")
@app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
@app_commands.allowed_installs(guilds=True, users=True)
async def profile(interaction: discord.Interaction):
    if not await gate(interaction):
        return
    user = interaction.user
    embed = discord.Embed(title=f"{user.display_name}'s profile", color=discord.Color.blurple())
    embed.add_field(name="Username", value=str(user), inline=True)
    embed.add_field(name="User ID", value=str(user.id), inline=True)
    embed.add_field(name="Account created", value=discord.utils.format_dt(user.created_at, style="D"), inline=False)
    if user.display_avatar:
        embed.set_thumbnail(url=user.display_avatar.url)
    embed.add_field(name="Linked to bot", value="Yes" if is_linked(user.id) else "No — use `/link`", inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="badges", description="Show publicly visible Discord profile badges")
@app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
@app_commands.allowed_installs(guilds=True, users=True)
async def badges(interaction: discord.Interaction):
    if not await gate(interaction):
        return
    flags = getattr(interaction.user, "public_flags", None)
    names = []
    if flags:
        try:
            names = [flag.name.replace("_", " ").title() for flag in flags if getattr(flags, flag.name, False)]
        except Exception:
            names = []
    embed = discord.Embed(title="Public profile badges", color=discord.Color.blurple())
    embed.description = "\n".join(f"• {name}" for name in names) if names else (
        "No public badge flags were returned for this account. Some profile decorations or "
        "badge details may not be exposed through the bot API."
    )
    embed.set_footer(text="This is read-only. The bot cannot unlock or modify badges.")
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="ask", description="Ask the AI assistant a question")
@app_commands.describe(question="What would you like to know?")
@app_commands.allowed_contexts(guilds=True, dms=True, private_channels=False)
@app_commands.allowed_installs(guilds=True, users=True)
async def ask(interaction: discord.Interaction, question: str):
    if not await gate(interaction):
        return
    await interaction.response.defer(ephemeral=True, thinking=True)
    answer = await ai_reply(question, str(interaction.user))
    await interaction.followup.send(answer, ephemeral=True)

@bot.tree.command(name="about", description="About Badge Buddy")
@app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
@app_commands.allowed_installs(guilds=True, users=True)
async def about(interaction: discord.Interaction):
    if not await gate(interaction):
        return
    await interaction.response.send_message(
        "Badge Buddy provides read-only profile and public badge information plus AI help. "
        "It does not fake activity, manipulate badge progress, or collect account tokens.",
        ephemeral=True
    )

@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return
    # The AI answers in DMs or servers only when directly mentioned.
    if bot.user and bot.user in message.mentions:
        if not await is_member_of_required_server(message.author.id):
            await message.reply(
                f"Please join the support server first: {SUPPORT_SERVER_INVITE}",
                mention_author=False
            )
            return
        prompt = message.content
        prompt = prompt.replace(f"<@{bot.user.id}>", "").replace(f"<@!{bot.user.id}>", "").strip()
        if not prompt:
            await message.reply("Mention me with a question, or use `/ask`.", mention_author=False)
            return
        async with message.channel.typing():
            answer = await ai_reply(prompt, str(message.author))
        await message.reply(answer, mention_author=False)
    await bot.process_commands(message)

@bot.event
async def on_member_join(member: discord.Member):
    # No action needed; membership is checked live whenever a command is used.
    pass

init_db()
bot.run(TOKEN)
