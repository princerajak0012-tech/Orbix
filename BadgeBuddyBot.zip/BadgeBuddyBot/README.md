# Badge Buddy Discord Bot

A deployable Python Discord bot for read-only public badge/profile information and AI help.

## Included commands

- `/link` — registers the invoking Discord identity with this bot. It does not request or store a user token.
- `/help` — DM-only command guide.
- `/profile` — DM-only profile basics.
- `/badges` — DM-only display of public badge flags exposed by Discord.
- `/ask` — AI question answering in DMs and servers.
- `/about` — DM-only bot information.
- Mention the bot (`@Bot your question`) — AI replies in DMs and servers.

Every command and AI mention checks that the user belongs to the required support server. If not, the bot sends the invite:
https://discord.gg/Mb6EwCcuk5

## Important limitation

This project intentionally does not implement `/spoofgame`, fake game activity, fake badge progress, user-token login, cookie collection, or unofficial analytics manipulation. Discord profile badges cannot be granted by this bot. `/badges` only displays public information available through the supported bot API.

## Setup

1. Create a Discord application and add a bot in the Discord Developer Portal.
2. Enable **Server Members Intent** and **Message Content Intent** under Bot → Privileged Gateway Intents.
3. Invite the bot to your support server with the `bot` and `applications.commands` scopes. Give it only the permissions it needs to operate and send messages.
4. Copy `.env.example` to `.env`.
5. Fill in `DISCORD_BOT_TOKEN` and `REQUIRED_GUILD_ID`.
6. Add `OPENAI_API_KEY` if you want AI answers.
7. Install dependencies and start:

   ```bash
   python -m pip install -r requirements.txt
   python bot.py
   ```

Commands are synced globally at startup. Discord may take a little time to display global commands.

## Hosting

Use Python 3.10+ and run `python bot.py` as the worker/start command. Keep `.env` private. Never upload it to GitHub or share bot/API keys.

## Environment variables

| Variable | Required | Purpose |
|---|---|---|
| `DISCORD_BOT_TOKEN` | Yes | Bot token from the Developer Portal |
| `REQUIRED_GUILD_ID` | Yes | ID of the server users must join |
| `OPENAI_API_KEY` | For AI | AI provider API key |
| `OPENAI_MODEL` | No | Defaults to `gpt-4o-mini` |
| `OPENAI_BASE_URL` | No | Defaults to OpenAI API |
| `SUPPORT_SERVER_INVITE` | No | Defaults to the supplied invite |
| `DATABASE_PATH` | No | SQLite database file |

## Notes

- Enable Developer Mode in Discord to copy the support server ID.
- The bot itself must be a member of the required support server.
- Do not collect Discord user account tokens. Users should never paste them into a bot.
- `/link` is an internal app registration, not OAuth login and not a credential-sharing flow.
